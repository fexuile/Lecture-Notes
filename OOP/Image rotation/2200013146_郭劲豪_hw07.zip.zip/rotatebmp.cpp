#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
#define BYTE char
#define WORD short
#define DWORD int
#define LONG long
typedef struct{
    BYTE R,G,B;
}IMAGE;
char zero='0';
int main(int argc,char* argv[]){
    FILE *input,*output;
    input = fopen(argv[1],"rb");output = fopen(argv[2],"wb");
    BITMAPFILEHEADER FILEHEADER,rot_FILEHEADER;BITMAPINFOHEADER INFOHEADER,rot_INFOHEADER;
    fread(&FILEHEADER,sizeof(BITMAPFILEHEADER),1,input);fread(&INFOHEADER,sizeof(BITMAPINFOHEADER),1,input);
    int h=INFOHEADER.biHeight,w=INFOHEADER.biWidth,add=(w*3+3)/4*4-w*3; 
    int size=INFOHEADER.biHeight*w;
    IMAGE* pre = (IMAGE*)malloc(sizeof(IMAGE)*size) , *ans = (IMAGE*)malloc(sizeof(IMAGE)*size);
    for(int i=0;i<INFOHEADER.biHeight;i++){
        fread((IMAGE*)pre+i*INFOHEADER.biWidth,sizeof(IMAGE),INFOHEADER.biWidth,input);
        fseek(input,add,SEEK_CUR);
    }
    rot_FILEHEADER = FILEHEADER; rot_INFOHEADER = INFOHEADER;
    rot_INFOHEADER.biHeight = w;rot_INFOHEADER.biWidth = h;
    int rot_add = (rot_INFOHEADER.biWidth*3+3)/4*4-rot_INFOHEADER.biWidth*3;
    rot_INFOHEADER.biSizeImage = (rot_INFOHEADER.biWidth*3+rot_add)*rot_INFOHEADER.biHeight;
    for(int i=0;i<h;i++)
        for(int j=0;j<w;j++)
            *(ans+(w-j-1)*h+i)=*(pre+i*w+j);

    fwrite(&rot_FILEHEADER,sizeof(BITMAPFILEHEADER),1,output);fwrite(&rot_INFOHEADER,sizeof(BITMAPINFOHEADER),1,output);
    for(int i=0;i<rot_INFOHEADER.biHeight;i++){
        fwrite((IMAGE*)ans+i*rot_INFOHEADER.biWidth,sizeof(IMAGE),rot_INFOHEADER.biWidth,output);
        fwrite(&zero,sizeof(BYTE),rot_add,output);
    }
    fclose(input);fclose(output);
    return 0;
}