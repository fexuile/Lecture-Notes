# README

## 运行系统要求

Win11，32/64位

## 源代码编译命令

```
g++ -o rotatebmp rotatebmp.cpp
```

## 运行命令

```
rotatebmp.exe a.bmp b.bmp
```

其中`a.bmp`,`b.cmp`分别代表两个bmp文件格式的文件，表示将`a.bmp`顺时针旋转90°，得到的图像保存在`b.bmp`内

